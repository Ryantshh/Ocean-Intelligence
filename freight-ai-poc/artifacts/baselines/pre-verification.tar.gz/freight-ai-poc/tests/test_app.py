from pathlib import Path

from streamlit.testing.v1 import AppTest


def test_streamlit_start_and_deterministic_query():
    app = AppTest.from_file(
        str(Path(__file__).resolve().parents[1] / "app/streamlit_app.py")
    )
    app.run(timeout=20)
    assert not app.exception
    next(b for b in app.button if b.label == "Run search").click().run()
    assert not app.exception
    assert app.session_state["response"]["tool_result"]["total_count"] == 1
    next(b for b in app.button if b.label == "Screen vessels").click().run()
    assert not app.exception
    assert app.session_state["screening"]["candidate_count"] == 1
